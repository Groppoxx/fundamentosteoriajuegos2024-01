#pragma once

const int SCREEN_INDEX_NO_SCREEN = -1;
const int SCREEN_INDEX_MENU = 0;
const int SCREEN_INDEX_GAMEPLAY = 1;
