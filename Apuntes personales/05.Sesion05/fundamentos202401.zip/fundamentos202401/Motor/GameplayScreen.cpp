#include "GameplayScreen.h"

GameplayScreen::GameplayScreen(Window* window)
{
}

GameplayScreen::~GameplayScreen()
{
}

void GameplayScreen::build()
{
}

void GameplayScreen::destroy()
{
}

void GameplayScreen::onExit()
{
}

void GameplayScreen::onEntry()
{
}

void GameplayScreen::update()
{
}

void GameplayScreen::draw()
{
}

void GameplayScreen::checkInput()
{
}

int GameplayScreen::getNextScreen() const
{
    return 0;
}

int GameplayScreen::getPreviousScreen() const
{
    return 0;
}
