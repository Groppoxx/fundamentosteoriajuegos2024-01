#include "App.h"
#include "ScreenList.h"

App::App()
{
}

App::~App()
{
}

void App::onInit()
{
}

void App::addScreen()
{
	/*menuScreen = std::make_unique<MenuScreen>(&window);
	screenList->addScreen(menuScreen.get());
	screenList->setCreen(menuScreen->getIndex());*/
}

void App::onExit()
{
}
